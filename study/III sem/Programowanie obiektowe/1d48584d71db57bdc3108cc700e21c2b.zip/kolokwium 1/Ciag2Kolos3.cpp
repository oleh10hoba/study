//============================================================================
// Name        : Ciag2.cpp
// Author      : Szymon Przebierowski
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Ciag{
private:
	int ilosc;
	int *skladowe;
public:
	Ciag(int ilosc=5){
		this->ilosc=ilosc;
		skladowe = new int[ilosc];
		for(int i=0; i<ilosc; i++) skladowe[i]=0;
	}
	void wpisz(int liczba, int pozycja){
		skladowe[pozycja]=liczba;
	}
	int maks(int &maksymalny){
		maksymalny=skladowe[0];
		int ile=1;
		for(int i=1; i<ilosc; i++){
			if(skladowe[i]>maksymalny){
				maksymalny=skladowe[i];
				ile=1;
			}
			else if(skladowe[i]==maksymalny) ile++;
		}
		return ile;
	}
	Ciag &smax(Ciag &nowy){
		int zmienna;
		if(this->maks(zmienna)>nowy.maks(zmienna)) return *this;
		return nowy;
	}
	void wyswietl(){
		for(int i=0; i<ilosc; i++){
			cout<<skladowe[i]<<" ";
		}
		cout<<endl;
		int maksymalny;
		cout<<"Ilosc: "<<this->maks(maksymalny);
		cout<<" Max: "<<maksymalny<<endl;
	}

};

int main() {
	Ciag pierwszy;
		Ciag drugi;
		pierwszy.wpisz(5,0);
		pierwszy.wpisz(4,1);
		pierwszy.wpisz(3,2);
		pierwszy.wpisz(5,3);
		pierwszy.wpisz(2,4);
		drugi.wpisz(6,0);
		drugi.wpisz(6,1);
		drugi.wpisz(6,2);
		drugi.wpisz(6,3);
		drugi.wpisz(6,4);
		pierwszy.wyswietl();
		drugi.wyswietl();
		(pierwszy.smax(drugi)).wyswietl();
	return 0;
}
