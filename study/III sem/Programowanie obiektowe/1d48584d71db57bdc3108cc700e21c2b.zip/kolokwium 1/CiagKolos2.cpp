//============================================================================
// Name        : Ciag.cpp
// Author      : Szymon Przebierowski
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Ciag{
private:
	int ilosc;
	int *skladowe;
public:
	Ciag(int ilosc=5){
		this->ilosc=ilosc;
		skladowe = new int[ilosc];
		for(int i=0; i<ilosc; i++) skladowe[i]=0;
	}
	void wpisz(int liczba, int pozycja){
		skladowe[pozycja]=liczba;
	}
	float srednia(){
		float suma=0;
		int ile=0;
		for(int i=0; i<ilosc; i++){
			if(skladowe[i]>0){
				suma+=skladowe[i];
				ile++;
			}
		}
		return suma/ile;
	}
	Ciag &wsred(Ciag &nowy){
		if(this->srednia()<nowy.srednia()) return *this;
		return nowy;
	}
	void wyswietl(){
		for(int i=0; i<ilosc; i++){
			cout<<skladowe[i]<<" ";
		}
		cout<<endl;
		cout<<"Srednia: "<<this->srednia()<<endl;
	}

};

int main() {
	Ciag pierwszy(3);
	Ciag drugi(3);
	pierwszy.wpisz(5,0);
	pierwszy.wpisz(4,1);
	pierwszy.wpisz(3,2);
	drugi.wpisz(6,0);
	drugi.wpisz(6,1);
	drugi.wpisz(6,2);
	pierwszy.wyswietl();
	drugi.wyswietl();
	(pierwszy.wsred(drugi)).wyswietl();

	return 0;
}
