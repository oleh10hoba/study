//============================================================================
// Name        : Tab.cpp
// Author      : Szymon Przebierowski
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Tab{
private:
	int ilosc;
	int *skladowe;
public:
	Tab(int ilosc=3){
		this->ilosc=ilosc;
		skladowe = new int[ilosc];
		for(int i=0; i<ilosc; i++) skladowe[i]=0;
	}
	void wpisz(int liczba){
		for(int i=0; i<ilosc; i++){
			if(skladowe[i]==0) {
                skladowe[i]=liczba;
                break;
			}
		}
	}
	int maksmin(int &maksymalna){
		int najmniejsza=skladowe[0];
		for(int i=1; i<ilosc; i++){
			if(skladowe[i]<najmniejsza){
				najmniejsza=skladowe[i];
			}
		}
		maksymalna=skladowe[0];
		for(int i=1; i<ilosc; i++){
			if(skladowe[i]>maksymalna){
				maksymalna=skladowe[i];
			}
		}
		return najmniejsza;
	}
	Tab& dmin(Tab &nowy){
		int zmienna;
		if(this->maksmin(zmienna)<nowy.maksmin(zmienna)) return *this;
		return nowy;
	}
	void wyswietl(){
		int maksymalna;
		for(int i=0; i<ilosc; i++) cout<<skladowe[i]<<" ";
		cout<<endl;
		cout<<"Najmniejsza: "<<this->maksmin(maksymalna)<<" Najwieszka: ";
		cout<<maksymalna<<endl;
	}

};

int main() {
	Tab pierwszy;
	Tab drugi;
	int liczba;
	cin>>liczba;
	pierwszy.wpisz(liczba);
	cin>>liczba;
	pierwszy.wpisz(liczba);
	cin>>liczba;
	pierwszy.wpisz(liczba);
	cin>>liczba;
	drugi.wpisz(liczba);
	cin>>liczba;
	drugi.wpisz(liczba);
	cin>>liczba;
	drugi.wpisz(liczba);
	pierwszy.wyswietl();
	drugi.wyswietl();
	(pierwszy.dmin(drugi)).wyswietl();
	return 0;
}
