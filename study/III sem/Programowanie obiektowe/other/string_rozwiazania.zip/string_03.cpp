#include <iostream>

using namespace std;

int main()
{
  string line;
  int length;

  getline(cin, line);
  length = line.length();

  for (int i = 0; i < length; ++i)
  {
    if (line[i] == ' ')
      line[i] = '_';
  }

  cout << line << endl;
}
