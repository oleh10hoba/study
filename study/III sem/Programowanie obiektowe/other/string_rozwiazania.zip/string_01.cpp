#include <iostream>

using namespace std;

int main()
{
  string line;

  getline(cin, line);

  cout << line.length() << endl;
}
