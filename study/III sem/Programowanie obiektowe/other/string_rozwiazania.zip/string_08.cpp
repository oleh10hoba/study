#include <iostream>

using namespace std;

int main()
{
  string line;
  getline(cin, line);

  int word_begin = 0;
  int word_end = line.find(' ');

  while (word_end != string::npos)
  {
    cout << line.substr(word_begin, word_end - word_begin) << endl;

    word_begin = word_end + 1;
    word_end = line.find(' ', word_begin);
  }

  if (word_begin != line.length())
    cout << line.substr(word_begin) << endl;
}
