#include <iostream>

using namespace std;

int main()
{
  string line;

  getline(cin, line);

  if (line.find("ala") != string::npos)
    cout << "slowo wystepuje" << endl;
  else
    cout << "slowo nie wystepuje" << endl;
}
