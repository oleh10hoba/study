#include <iostream>

using namespace std;

int main()
{
  string input;
  string output;

  // wczytanie pierwszego slowa - mozna wczytac bezposrednio do zmiennej output
  getline(cin, input);
  output = input;

  // wczytanie pozostalych czterech slow
  for (int i = 0; i < 4; ++i)
  {
    getline(cin, input);
    output += ' ' + input;
  }

  cout << output << endl;
}
