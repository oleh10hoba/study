#include <iostream>

using namespace std;

int main()
{
  string line;
  getline(cin, line);

  int position = line.find('a');

  while (position != string::npos)
  {
    line.insert(position + 1, "aa");
    position = line.find('a', position + 3); // przesuniecie o 1 + dlugosc "aa"
  }

  cout << line << endl;
}
