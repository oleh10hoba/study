#include <iostream>

using namespace std;

int main()
{
  string line;
  int length;
  int counter = 0;

  getline(cin, line);
  length = line.length();

  for (int i = 0; i < length; ++i)
  {
    if (line[i] == 'a')
      counter++;
  }

  cout << counter << endl;
}
