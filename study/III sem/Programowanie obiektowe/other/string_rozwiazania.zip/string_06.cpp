#include <iostream>

using namespace std;

int main()
{
  string line;
  int position;
  int counter = 0;

  getline(cin, line);

  position = line.find("ala");

  while (position != string::npos)
  {
    counter++;
    position = line.find("ala", position + 3); // 3 == dlugosc slowa "ala"
  }

  cout << counter << endl;
}
