#include <iostream>

using namespace std;

int main()
{
  string line;
  getline(cin, line);

  int length = line.length();

  for (int i = 0; i < length; ++i)
  {
    if ((line[i] >= 'a') && (line[i] <= 'z'))
      line[i] += ('A' - 'a');
  }

  cout << line << endl;
}
