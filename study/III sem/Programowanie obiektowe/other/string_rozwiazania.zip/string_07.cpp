#include <iostream>

using namespace std;

int main()
{
  string line;
  int length;

  getline(cin, line);
  length = line.length();

  for (int i = length - 1; i >= 0; --i)
  {
    if (line[i] == ' ')
      line.erase(i, 1);
  }

  cout << line << endl;
}
