#include <fstream>
#include <iostream>

using namespace std;


int main(int argc, char** argv)
{
  // argv[0] - nazwa programu
  // argv[1] - sciezka do pliku wejsciowego (pierwszy argument podany przez uzytkownika)
  // argv[2] - sciezka do pliku wyjsciowego
  // argv[3 .. argc-1] - numery linii

  ifstream inFile(argv[1]);

  if (inFile.is_open())
  {
    ofstream outFile(argv[2]);

    if (outFile.is_open())
    {
      string data;
      int fileLineIndex = 0;
      int argIndex = 3;
      int argLineIndex = atoi(argv[3]);

      while ((argIndex < argc) && (getline(inFile, data)))
      {
        if (fileLineIndex == argLineIndex)
        {
          outFile << data << endl;

          argIndex++;
          argLineIndex = atoi(argv[argIndex]);
        }

        fileLineIndex++;
      }

      outFile.close();
    }

    inFile.close();
  }

  return 0;
}
