#include <fstream>
#include <iostream>

using namespace std;


void differentFiles(int argc, char** argv)
{
  ifstream inFile(argv[1]);

  if (inFile.is_open())
  {
    ofstream outFile(argv[2]);

    if (outFile.is_open())
    {
      string data;
      int fileLineIndex = 0;
      int argIndex = 3;
      int argLineIndex = atoi(argv[3]);

      while ((argIndex < argc) && (getline(inFile, data)))
      {
        if (fileLineIndex == argLineIndex)
        {
          outFile << data << endl;

          argIndex++;
          argLineIndex = atoi(argv[argIndex]);
        }

        fileLineIndex++;
      }

      outFile.close();
    }

    inFile.close();
  }
}


void sameFile(int argc, char** argv)
{
  fstream file(argv[1], ios::in | ios::out);

  if (file.is_open())
  {
    string data;
    int fileLineIndex = 0;
    int argIndex = 3;
    int argLineIndex = atoi(argv[3]);

    while ((argIndex < argc) && (getline(file, data)))
    {
      cout << data << " " << fileLineIndex << endl;

      if (fileLineIndex == argLineIndex)
      {
        int readPosition = file.tellg(); // zapamietaj pozycje odczytu

        file.seekp(0, ios_base::end);    // skok na koniec pliku
        file << data << endl;            // zapis na koncu pliku

        file.seekg(readPosition);        // powrot do miejsca odczytu

        argIndex++;
        argLineIndex = atoi(argv[argIndex]);
      }

      fileLineIndex++;
    }

    file.close();
  }
}


int main(int argc, char** argv)
{
  // argv[0] - nazwa programu
  // argv[1] - sciezka do pliku wejsciowego (pierwszy argument podany przez uzytkownika)
  // argv[2] - sciezka do pliku wyjsciowego
  // argv[3 .. argc-1] - numery linii

  if (string(argv[1]) == string(argv[2]))
  {
    sameFile(argc, argv);
  }
  else
  {
    differentFiles(argc, argv);
  }

  return 0;
}
