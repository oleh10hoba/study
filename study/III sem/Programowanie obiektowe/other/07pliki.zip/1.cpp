#include <fstream>
#include <iostream>

using namespace std;


int main(int argc, char** argv)
{
  // argv[0] - nazwa programu
  // argv[1] - sciezka do pliku (pierwszy argument podany przez uzytkownika)
  // argv[2 .. argc-1] - numery linii

  ifstream file(argv[1]);

  if (file.is_open())
  {
    string data;
    int fileLineIndex = 0;
    int argIndex = 2;
    int argLineIndex = atoi(argv[2]);

    while ((argIndex < argc) && (getline(file, data)))
    {
      if (fileLineIndex == argLineIndex)
      {
        cout << data << endl;

        argIndex++;
        argLineIndex = atoi(argv[argIndex]);
      }

      fileLineIndex++;
    }

    file.close();
  }

  return 0;
}
