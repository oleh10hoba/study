#include <fstream>
#include <iostream>

using namespace std;


class Student
{
  protected:
    string imie;
    string nazwisko;

  public:
    Student()
    {
    }

    Student(string imie, string nazwisko)
    {
      this -> imie = imie;
      this -> nazwisko = nazwisko;
    }

    string getImie()
    {
      return imie;
    }

    string getNazwisko()
    {
      return nazwisko;
    }

    void zapisz(string sciezka)
    {
      fstream plik(sciezka.c_str(), ios::out);

      plik << imie << endl << nazwisko << endl;

      plik.close();
    }

    void wczytaj(string sciezka)
    {
      fstream plik(sciezka.c_str(), ios::in);

      getline(plik, imie);
      getline(plik, nazwisko);

      plik.close();
    }
};


int main()
{
  Student pierwszy("Jan", "Kowalski");
  pierwszy.zapisz("student.txt");

  Student drugi;
  drugi.wczytaj("student.txt");

  cout << drugi.getImie() << " " << drugi.getNazwisko() << endl;

  return 0;
}
