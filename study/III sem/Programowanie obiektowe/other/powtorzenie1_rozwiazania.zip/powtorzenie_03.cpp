#include <iostream>

using namespace std;


class KonwerterTekstu
{
  public:
    string usunSpacje(string dane)
    {
      for (int i = dane.length() - 1; i >= 0; --i)
      {
        if (dane[i] == ' ')
          dane.erase(i, 1);
      }

      return dane;
    }

    string odwrocZnaki(string dane)
    {
      int length = dane.length();

      for (int i = 0; i < length; ++i)
      {
        if ((dane[i] >= 'a') && (dane[i] <= 'z'))
          dane[i] += ('A' - 'a');

        else if ((dane[i] >= 'A') && (dane[i] <= 'Z'))
          dane[i] += ('a' - 'A');
      }

      return dane;
    }
};


int main()
{
  KonwerterTekstu konwerter;

  cout << konwerter.usunSpacje("Ala Ma Kota") << endl;
  cout << konwerter.odwrocZnaki("Ala Ma Kota") << endl;

  return 0;
}
