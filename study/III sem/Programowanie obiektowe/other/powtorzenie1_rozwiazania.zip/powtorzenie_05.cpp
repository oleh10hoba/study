#include <iostream>

using namespace std;


class Licznik
{
  private:
    int liczba;

  public:
    Licznik(int poczatkowa)
    {
      liczba = poczatkowa;
    }

    int getLiczba()
    {
      return liczba;
    }

    void podnies()
    {
      liczba++;
    }
};


class LicznikOdZera: public Licznik
{
  public:
    LicznikOdZera():
      Licznik(0)
    {
      // pole jest prywatne, wiec jedyna mozliwosc to lista inicjalizacyjna
    }
};


int main()
{
  LicznikOdZera licznik;

  cout << licznik.getLiczba() << endl;

  return 0;
}
