class StudentKierunek: public Student
{
  protected:
    string kierunek;

  public:
    StudentKierunek(string imie, string nazwisko, string kierunek):
      Student(imie, nazwisko)
    {
      this -> kierunek = kierunek;

      // pola imie i nazwisko sa chronione - klasa pochodna ma do nich dostep
      // mozna ustawic wszystkie trzy wartosci bez uzycia listy inicjalizacyjnej
    }

    void zapisz(string sciezka)
    {
      fstream plik(sciezka.c_str(), ios::out);

      plik << imie << endl << nazwisko << endl << kierunek << endl;

      plik.close();
    }

    void wczytaj(string sciezka)
    {
      fstream plik(sciezka.c_str(), ios::in);

      getline(plik, imie);
      getline(plik, nazwisko);
      getline(plik, kierunek);

      plik.close();
    }
};
