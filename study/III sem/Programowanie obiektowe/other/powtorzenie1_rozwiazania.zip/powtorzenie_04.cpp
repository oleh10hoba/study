#include <iostream>
#include <sstream>

using namespace std;


class Komunikat
{
  private:
    string nazwa;

  public:
    Komunikat(string n)
    {
      nazwa = n;
      cout << nazwa << " - konstruktor" << endl;
    }

    ~Komunikat()
    {
      cout << nazwa << " - destruktor" << endl;
    }
};


int main()
{
  const int liczba = 4;

  Komunikat** tablica = new Komunikat*[liczba];

  for (int i = 0; i < liczba; ++i)
  {
    stringstream s;
    string nazwa;

    s << i;
    s >> nazwa;

    tablica[i] = new Komunikat(nazwa);
  }

  for (int i = liczba - 1; i >= 0; --i)
    delete tablica[i];
}
