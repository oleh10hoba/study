#include <iostream>
#include <fstream>
#include <sstream>
#include <regex>


using namespace std;

class MathFile
{
private:
    string filename;
    fstream file;

public:
    MathFile(string filename):
        filename(filename)
    {
    }

    void open()
    {
        file.open(filename.c_str(), ios::in | ios::out);
    }

    void close()
    {
        file.close();
    }

    string getRow(int index)
    {
        string row;

        file.seekg(0); // wroc na poczatek pliku

        for (int i = 0; i <= index; ++i)
        {
            if (! getline(file, row))
            {
                throw runtime_error("end of file");
            }
        }

        return row;
    }

    int sumRow(int index)
    {
        string row = getRow(index);
        int token;
        int sum = 0;

        stringstream s;
        s << row;

        while (s >> token)
        {
            sum += token;
        }

        return sum;
    }

    bool verifyRow(int index)
    {
        regex pattern_operator("\\+|-|=");
        regex pattern_number("\\d+");

        string row = getRow(index);
        string token;

        stringstream s;
        s << row;

        int currentValue = 0;
        string currentOperator = "";

        while (s >> token)
        {
            if (regex_match(token, pattern_operator))
            {
                currentOperator = token;
            }
            else if (regex_match(token, pattern_number))
            {
                if (currentOperator.empty())
                {
                    currentValue = atoi(token.c_str());
                }
                else if (currentOperator == "+")
                {
                    currentValue += atoi(token.c_str());
                }
                else if (currentOperator == "-")
                {
                    currentValue -= atoi(token.c_str());
                }
                else if (currentOperator == "=")
                {
                    return (currentValue == atoi(token.c_str()));
                }
            }
        }

        return false;
    }

    void append(string line)
    {
        if (file.is_open())
        {
            file.seekp(0, ios_base::end);
            file << line << endl;
        }
    }
};


ostream& operator<<(ostream& stream, MathFile& file)
{
    bool fileReady = true;
    int lineCounter = 0;

    while (fileReady)
    {
        try
        {
            stream << file.verifyRow(lineCounter);
            lineCounter++;
        }
        catch (runtime_error& e)
        {
            fileReady = false;
        }
    }

    return stream;
}


istream& operator>>(istream& stream, MathFile& file)
{
    string token;
    string line = "";

    while (token != "=")
    {
        stream >> token;
        line += token + ' ';
    }

    stream >> token;
    line += token;

    file.append(line);

    return stream;
}


int main(int argc, char *argv[])
{
    MathFile file("plik.txt");
    file.open();

    cin >> file;

    file.close();

    return 0;
}
