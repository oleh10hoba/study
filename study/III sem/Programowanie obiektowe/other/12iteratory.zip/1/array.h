#ifndef ARRAY_H
#define ARRAY_H


#include "iterator.h"


template <typename T>
class Array {


private:
    unsigned int m_size;
    T *arr;

public:
    Array(int size);
    ~Array();
    int size();
    T& operator[](int index);

    Iterator<T> begin()
    {
        return Iterator<T>(arr);
    }

    Iterator<T> end()
    {
        return Iterator<T>(arr + m_size);
    }
};


template <typename T>
Array<T>::Array(int size) {
    this->m_size=size;
    this->arr=new T[size];
}

template <typename T>
Array<T>::~Array() {
    delete [] arr;
}

template <typename T>
int Array<T>::size() {
    return m_size;
}

template <typename T>
T& Array<T>::operator[](int index) {
    return arr[index];
}

#endif // ARRAY_H
