#include "array.h"
#include <iostream>


using namespace std;


int main(int argc, char *argv[])
{
    Array<int> a(5);

    a[0] = 5;
    a[1] = 10;
    a[2] = 15;
    a[3] = 20;
    a[4] = 25;

    for (Iterator<int> i = a.begin(); i != a.end(); ++i)
    {
        cout << *i << endl;
    }

    return 0;
}
