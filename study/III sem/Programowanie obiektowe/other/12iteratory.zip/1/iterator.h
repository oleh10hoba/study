#ifndef ITERATOR_H
#define ITERATOR_H

template <typename T>
class Iterator
{
private:
    T* element;

public:
    Iterator(T* e)
    {
        element = e;
    }

    Iterator& operator++()           // ++i
    {
        ++element;
        return *this;
    }

    Iterator operator++(int dummy)   // i++
    {
        Iterator copy(element);
        ++element;
        return copy;
    }

    T& operator*()
    {
        return *element;
    }

    bool operator==(const Iterator<T>& other)
    {
        return (element == other.element);
    }

    bool operator!=(const Iterator<T>& other)
    {
        return ! (*this == other);
    }
};


#endif // ITERATOR_H
