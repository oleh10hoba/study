#include <iostream>

using namespace std;


template <typename T>
class Lista
{
private:
    struct element
    {
        T wartosc;
        element* nastepny;
    };


public:
    class iterator
    {
    private:
        element* e;

    public:
        iterator(element* e)
        {
            this->e = e;
        }

        T& operator*()
        {
            return e->wartosc;
        }

        iterator& operator++()    // ++i
        {
            e = e->nastepny;
            return *this;
        }

        iterator operator++(int) // i++
        {
            iterator kopia(e);
            e = e->nastepny;
            return kopia;
        }

        bool operator==(const iterator& inny)
        {
            return (e == inny.e);
        }

        bool operator!=(const iterator& inny)
        {
            return ! (*this == inny);
        }
    };


private:
    element* poczatek;
    element* koniec;


public:
    Lista()
    {
        poczatek = nullptr;
        koniec = nullptr;
    }

    void dodajNaKoniec(T wartosc)
    {
        element* nowyElement = new element;
        nowyElement->wartosc = wartosc;
        nowyElement->nastepny = nullptr;

        if (koniec != nullptr) // czy sa jakies elementy na liscie
        {
            koniec->nastepny = nowyElement;
        }
        else                   // lista jest pusta
        {
            poczatek = nowyElement;
        }

        koniec = nowyElement;
    }

    void dodajNaPoczatek(T wartosc)
    {
        element* nowyElement = new element;
        nowyElement->wartosc = wartosc;
        nowyElement->nastepny = poczatek;

        poczatek = nowyElement;

        if (koniec == nullptr) // lista byla pusta
        {
            koniec = nowyElement;
        }
    }

    iterator begin()
    {
        return iterator(poczatek);
    }

    iterator end()
    {
        return iterator(nullptr);
    }
};


int main(int argc, char *argv[])
{
    Lista<int> l;

    l.dodajNaKoniec(3); // 3
    l.dodajNaKoniec(4); // 3 4

    l.dodajNaPoczatek(2); // 2 3 4
    l.dodajNaPoczatek(1); // 1 2 3 4

    l.dodajNaKoniec(5); // 1 2 3 4 5

    for (Lista<int>::iterator i = l.begin(); i != l.end(); ++i)
    {
        cout << *i << endl;
    }

    return 0;
}
