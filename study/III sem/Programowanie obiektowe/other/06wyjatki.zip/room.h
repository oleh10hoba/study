#ifndef ROOM_H
#define ROOM_H


#include "oversizeddoorexception.h"
#include "furnituredoorexception.h"
#include "furnitureroomexception.h"


struct Room
{
  private:
    float length;
    float width;
    float height;
    float widthDoor;
    float heightDoor;
    float freeSpace;

  public:
    Room();
    Room(float length, float width, float height, float widthDoor, float heightDoor);

    bool addFurniture(float length, float width, float height);
};


#endif
