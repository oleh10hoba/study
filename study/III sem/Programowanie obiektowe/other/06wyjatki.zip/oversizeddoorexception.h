#ifndef OVERSIZED_DOOR_EXCEPTION_H
#define OVERSIZED_DOOR_EXCEPTION_H


#include <stdexcept>


class OversizedDoorException: public std::exception
{
  private:
    const float widthOver;
    const float heightOver;

  public:
    OversizedDoorException(float widthOver, float heightOver);
    const char* what() const noexcept;
};


#endif
