#include "house.h"
#include <iostream>


void invalidRoomIndex()
{
  Room rooms[3];
  House house(rooms, 3);

  try
  {
    house.getRoom(3);
  }
  catch (std::out_of_range& exception)
  {
    std::cout << exception.what() << std::endl;
  }
}


void oversizedDoor()
{
  try
  {
    Room room(4, 5, 3, 6, 3.5);
  }
  catch (OversizedDoorException& exception)
  {
    std::cout << exception.what() << std::endl;
  }
}


void furnitureDoor()
{
  Room room(5, 5, 3, 1, 2);

  try
  {
    room.addFurniture(1, 1.5, 2);
  }
  catch (FurnitureException& exception)
  {
    std::cout << exception.what() << std::endl;
  }
}


void furnitureRoom()
{
  Room room(5, 5, 3, 1, 2);

  try
  {
    room.addFurniture(10, 0.5, 0.5);
  }
  catch (FurnitureException& exception)
  {
    std::cout << exception.what() << std::endl;
  }
}


int main()
{
  invalidRoomIndex();
  oversizedDoor();
  furnitureDoor();
  furnitureRoom();

  return 0;
}
