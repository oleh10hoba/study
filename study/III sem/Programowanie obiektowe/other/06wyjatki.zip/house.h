#ifndef HOUSE_H
#define HOUSE_H


#include "room.h"
#include <stdexcept>


class House
{
  private:
    Room* rooms;
    int roomsSize;

  public:
    House(Room* rooms, int size);
    Room& getRoom(int index);
};


#endif
