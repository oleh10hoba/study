#include "furnitureroomexception.h"


const char* FurnitureRoomException::what() const noexcept
{
  return "furniture room exception";
}
