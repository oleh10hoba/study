#ifndef FURNITURE_EXCEPTION_H
#define FURNITURE_EXCEPTION_H


#include <stdexcept>


class FurnitureException: public std::exception
{
};


#endif
