#include "oversizeddoorexception.h"


OversizedDoorException::OversizedDoorException(float widthOver, float heightOver):
  widthOver(widthOver),
  heightOver(heightOver)
{
}


const char* OversizedDoorException::what() const noexcept
{
  std::string message = "width over: " + std::to_string(widthOver) + ", height over: " + std::to_string(heightOver);
  return message.c_str();
}
