#ifndef FURNITURE_ROOM_EXCEPTION_H
#define FURNITURE_ROOM_EXCEPTION_H


#include "furnitureexception.h"


class FurnitureRoomException: public FurnitureException
{
  public:
    const char* what() const noexcept;
};


#endif
