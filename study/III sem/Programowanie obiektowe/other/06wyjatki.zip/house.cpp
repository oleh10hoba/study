#include "house.h"


House::House(Room* rooms, int size)
{
  this->rooms = new Room[size];
  roomsSize = size;

  for (int i = 0; i < size; ++i)
  {
    this->rooms[i] = rooms[i];
  }
}


Room& House::getRoom(int index)
{
  if ((index < 0) || (index >= roomsSize))
  {
    throw std::out_of_range("invalid room index");
  }

  return rooms[index];
}
