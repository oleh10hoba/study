#include "furnituredoorexception.h"


const char* FurnitureDoorException::what() const noexcept
{
  return "furniture door exception";
}
