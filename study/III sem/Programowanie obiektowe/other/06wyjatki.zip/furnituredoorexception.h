#ifndef FURNITURE_DOOR_EXCEPTION_H
#define FURNITURE_DOOR_EXCEPTION_H


#include "furnitureexception.h"


class FurnitureDoorException: public FurnitureException
{
  public:
    const char* what() const noexcept;
};


#endif
