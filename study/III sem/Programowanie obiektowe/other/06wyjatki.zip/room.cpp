#include "room.h"


Room::Room()
{
}


Room::Room(float length, float width, float height, float widthDoor, float heightDoor):
  length(length),
  width(width),
  height(height),
  widthDoor(widthDoor),
  heightDoor(heightDoor)
{
  if ((widthDoor > width) || (heightDoor > height))
  {
    float widthOver = std::max(widthDoor - width, 0.0f);
    float heightOver = std::max(heightDoor - height, 0.0f);

    throw OversizedDoorException(widthOver, heightOver);
  }

  freeSpace = width * length;
}


bool Room::addFurniture(float length, float width, float height)
{
  // w rzeczywistym przypadku nalezaloby rozpatrzyc znacznie wiecej mozliwosci
  // mebel mozna wniesc do pokoju na kilka roznych sposobow

  if ((width > widthDoor) || (height > heightDoor))
  {
    throw FurnitureDoorException();
  }

  if ((length > this->length) || (width > this->width) || (height > this->height))
  {
    throw FurnitureRoomException();
  }

  float furnitureSpace = length * width;

  if (furnitureSpace <= freeSpace)
  {
    freeSpace -= furnitureSpace;
    return true;
  }
  else
  {
    return false;
  }
}
